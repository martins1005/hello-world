<body bgColor="#FFFFFF">
	<center><h1>DR HOUSE 2019</h1></center>
	<br>
	<hr>
<?php

	$clikson = 0;
	$clicksoff = 0;
	$clickwindowson = 0;
	$clickwindowsoff = 0;
	$clickandroidon = 0;
	$clickandroidoff = 0;
	$clickiphoneon = 0;
	$clickiphoneoff = 0;
	$clicklinuxon = 0;
	$clicklinuxoff = 0;
	
	
	$conta = 0;
	$lista = array();

	$pasta = "./indexx";

	$pasta = opendir($pasta);
	while ($file = readdir($pasta)) {
       if (!is_dir($file) && $file != "." && $file != "..") {
				++$conta;
				$lista[] = $file;

				//Inicio Incrementa se encontrar "ON.txt" no nome do arquivo
				if(strpos("$file","ON.txt") !== false)
				{
					++$clikson;
					
					//Inicio Incrementa se encontrar "ON.txt" e "Windows" no nome do arquivo
					if(strpos("$file","Windows") !== false)
					{
						++$clickwindowson;
					}
					
					//Inicio Incrementa se encontrar "ON.txt" e "Android" no nome do arquivo
					if(strpos("$file","Android") !== false)
					{
						++$clickandroidon;
					}					
					

					//Inicio Incrementa se encontrar "ON.txt" e "iPhone" no nome do arquivo
					if(strpos("$file","iPhone") !== false)
					{
						++$clickiphoneon;
					}				


					//Inicio Incrementa se encontrar "ON.txt" e "Linux" no nome do arquivo
					if(strpos("$file","Linux") !== false)
					{
						++$clicklinuxon;
					}			
					
				} else {
					++$clicksoff;
					
					//Inicio Incrementa se encontrar "OFF.txt" e "Windows" no nome do arquivo
					if(strpos("$file","Windows") !== false)
					{
						++$clickwindowsoff;
					}					
					
					//Inicio Incrementa se encontrar "OFF.txt" e "Android" no nome do arquivo
					if(strpos("$file","Android") !== false)
					{
						++$clickandroidoff;
					}	
					
					//Inicio Incrementa se encontrar "OFF.txt" e "iPhone" no nome do arquivo
					if(strpos("$file","iPhone") !== false)
					{
						++$clickiphoneoff;
					}	
					
					//Inicio Incrementa se encontrar "OFF.txt" e "Linux" no nome do arquivo
					if(strpos("$file","Linux") !== false)
					{
						++$clicklinuxoff;
					}			
					
				}
				//Inicio Incrementa se encontrar "ON.txt" no nome do arquivo
				
				 
				
				
				
       }
	}
    closedir($dir);
    krsort($list);	

	$conta = count($lista);
	print "<font face=\"verdana\">&rsaquo;Cliques Geral [$conta]<br>\n";
	print "<font face=\"verdana\">&rsaquo;Cliques ON [$clikson]<br>\n";
	print "<font face=\"verdana\">&rsaquo;Cliques OFF [$clicksoff]<br>\n";
	print "<font face=\"verdana\">&rsaquo;Cliques Windows ON[$clickwindowson]<br>\n";
	print "<font face=\"verdana\">&rsaquo;Cliques Windows OFF[$clickwindowsoff]<br>\n";
	print "<font face=\"verdana\">&rsaquo;Cliques Android ON[$clickandroidon]<br>\n";
	print "<font face=\"verdana\">&rsaquo;Cliques Android OFF[$clickandroidoff]<br>\n";
	print "<font face=\"verdana\">&rsaquo;Cliques Iphone ON[$clickiphoneon]<br>\n";
	print "<font face=\"verdana\">&rsaquo;Cliques Iphone OFF[$clickiphoneoff]<br>\n";
	print "<font face=\"verdana\">&rsaquo;Cliques Linux ON[$clicklinuxon]<br>\n";
	print "<font face=\"verdana\">&rsaquo;Cliques Linux OFF[$clicklinuxoff]<br>\n";
	print "==============================================================================================================================<br>\n";

	for ($i = 0; $i < count($lista); $i++) {
       print $lista[$i] . "<br>\n";
	}
	
	print "==============================================================================================================================<br>\n";

	
?>

</font>
<hr>
</body>